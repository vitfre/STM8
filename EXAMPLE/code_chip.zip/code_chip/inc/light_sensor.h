#ifndef _LIGHT_SENSOR
#define _LIGHT_SENSOR

void uart_send_byte(uint8_t data);
void uart_send_msg(uint16_t val);
uint16_t get_adc_data(uint8_t ADC1_Channel);
void light_sensor_handler(void);
uint16_t array_analyse(void);
void init_light_buffer(void);


#endif