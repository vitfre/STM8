#ifndef _INIT
#define _INIT

#define LED1_PIN GPIO_PIN_2 //blue
#define LED1_PORT GPIOD

#define LED2_PIN GPIO_PIN_3 //red
#define LED2_PORT GPIOD

#define TSOP_PIN GPIO_PIN_1
#define TSOP_PORT GPIOC

#define RELAY_PIN GPIO_PIN_6
#define RELAY_PORT GPIOE

#define PWM_PIN GPIO_PIN_4
#define PWM_PORT GPIOD


#define UART_PIN GPIO_PIN_5
#define UART_PORT GPIOD

//power control
#define STAND_BY_PIN GPIO_PIN_5
#define STAND_BY_PORT GPIOA

//���� �������� �������
#define AC_DC_PIN GPIO_PIN_4
#define AC_DC_PORT GPIOB


#define OPEN_SENSOR_PIN GPIO_PIN_3
#define OPEN_SENSOR_PORT GPIOB

#define CLOSE_SENSOR_PIN GPIO_PIN_2
#define CLOSE_SENSOR_PORT GPIOB

#define AUTO_PIN GPIO_PIN_5 //������
#define AUTO_PORT GPIOB

void init_all(void);
void init_clk(void);
void init_gpio(void);
void init_timers(void);
void init_uart(void);
void IWDG_Config(void);
void init_clk(void);
void init_adc(void);

#endif