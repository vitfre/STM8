#include "stm8s.h"
#include <stdbool.h>

#ifndef _TIMEBASE
#define _TIMEBASE

void set_delay_timer(uint16_t value);
void set_tsop_timer(uint16_t value);
void set_motor_timer(uint16_t value);
void set_relay_timer(uint16_t value);
void set_power_timer(uint16_t value);
void set_sensor_timer(uint16_t value);
void set_led_timer(uint16_t value);
void set_button_timer(uint16_t value);

bool delay_timer_elapsed(void);
bool tsop_timer_elapsed(void);
bool motor_timer_elapsed(void);
bool relay_timer_elapsed(void);
bool power_timer_elapsed(void);
bool sensor_timer_elapsed(void);
bool led_timer_elapsed(void);
bool button_timer_elapsed(void);

void delay(uint16_t time);

#endif