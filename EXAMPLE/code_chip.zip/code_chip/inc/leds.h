#ifndef _LEDS
#define _LEDS

void enable_blue_led(void);
void enable_red_led(void);
void disable_leds(void);
void leds_handler(void);

#endif