#include <stdbool.h>

#ifndef _MOTOR
#define _MOTOR


typedef enum
{
  CMD_NONE = 0,
  CMD_OPEN,
  CMD_CLOSE,
  CMD_STOP,
}Drive_Command_Type;

typedef enum
{
  MOTOR_STOPPED = 0,
  MOTOR_RUNING,
  MOTOR_WAITING_RELAY, //�������� ����
  MOTOR_WAITING_POWER
}Motor_Status_Type;


typedef enum
{
  POS_OPENED = 0,
  POS_CLOSED,
  POS_UNKNOWN,
}Motor_Pos_Type;



void set_motor_speed(uint8_t value);
void set_relay_open(void);
void set_relay_close(void);
void enable_power(void);
void disable_power(void);
void motor_handler(void);
void start_drive(Drive_Command_Type cmd, uint16_t timeout,bool auto_stop);
void stop_motor(void);
void motor_beep(void);
bool auto_start_drive(Drive_Command_Type cmd);

#endif