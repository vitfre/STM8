#ifndef _CONTROL
#define _CONTROL

typedef enum
{
  AUTO = 0,
  MANUAL
}Auto_Status_Type;

void tsop_handler(void);
void set_auto_mode(void);
void light_control_handler(void);
void run_motor_by_light_value(void);
void light_control_handler(void);
void check_sensor(void);
void check_motor_power(void);


#endif