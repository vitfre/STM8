#include "init.h"
#include "stm8s_clk.h"
#include "stm8s_gpio.h"
#include "stm8s.h"
#include "stm8s_uart2.h"
#include "stm8s_tim4.h"
#include "stm8s_itc.h"
#include "stm8s_adc1.h"

void init_all(void)
{
  init_clk();
  init_gpio();
  init_timers();
  init_uart();
  init_adc();
  IWDG_Config();
}

void init_clk(void)
{

    CLK_DeInit();                                                                                                                                       
    // after reset Fclk = HSI / 8 = 2MHz 
    CLK_ClockSwitchConfig(CLK_SWITCHMODE_AUTO, CLK_SOURCE_HSE, DISABLE, CLK_CURRENTCLOCKSTATE_DISABLE);
    CLK_ClockSecuritySystemEnable();
}


void init_gpio(void)
{
  GPIO_DeInit(GPIOB);
    
  GPIO_Init(LED1_PORT, LED1_PIN, GPIO_MODE_OUT_PP_LOW_FAST);//led1
  GPIO_Init(LED2_PORT, LED2_PIN, GPIO_MODE_OUT_PP_LOW_FAST);//led2
  GPIO_Init(RELAY_PORT, RELAY_PIN, GPIO_MODE_OUT_PP_LOW_FAST);//relay
  GPIO_Init(PWM_PORT, PWM_PIN, GPIO_MODE_OUT_PP_LOW_FAST);//relay
  GPIO_Init(STAND_BY_PORT, STAND_BY_PIN, GPIO_MODE_OUT_PP_LOW_FAST);//power
  
  GPIO_WriteLow(LED1_PORT, LED1_PIN);
  GPIO_WriteLow(LED2_PORT, LED2_PIN);
  GPIO_WriteLow(PWM_PORT, PWM_PIN);
  GPIO_WriteLow(RELAY_PORT, RELAY_PIN);
  GPIO_WriteLow(STAND_BY_PORT, STAND_BY_PIN);
    
  GPIO_Init(TSOP_PORT, TSOP_PIN, GPIO_MODE_IN_FL_NO_IT);//tsop
  
  GPIO_Init(OPEN_SENSOR_PORT, OPEN_SENSOR_PIN, GPIO_MODE_IN_FL_NO_IT);//sensor
  GPIO_Init(CLOSE_SENSOR_PORT, CLOSE_SENSOR_PIN, GPIO_MODE_IN_FL_NO_IT);//sensor
  
  GPIO_Init(AUTO_PORT, AUTO_PIN, GPIO_MODE_IN_PU_NO_IT);//sensor
  GPIO_Init(AC_DC_PORT, AC_DC_PIN, GPIO_MODE_IN_PU_NO_IT);//power input
  
  GPIO_Init(UART_PORT, UART_PIN, GPIO_MODE_OUT_PP_LOW_FAST);//uart
  
}


void init_timers(void)
{
  
  ITC_SetSoftwarePriority(ITC_IRQ_TIM4_OVF, ITC_PRIORITYLEVEL_1);
  ITC_SetSoftwarePriority(ITC_IRQ_TIM1_CAPCOM, ITC_PRIORITYLEVEL_3);
  
  //��������� ������
  TIM4_DeInit();
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER4, ENABLE);
  TIM4_TimeBaseInit(TIM4_PRESCALER_128,124);//16M / 128 / 125 = 1000
  TIM4_SetAutoreload(124);
  
  TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
  TIM4_Cmd(ENABLE); 
  

  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER2, ENABLE);
  
  
 
  //TIM1 - TSOP 
  // ����� ������
  TIM1_TimeBaseInit(1024,TIM1_COUNTERMODE_UP,0xFFFF,0);
 
  TIM1_ICInit(TIM1_CHANNEL_1, TIM1_ICPOLARITY_RISING,TIM1_ICSELECTION_DIRECTTI, TIM1_ICPSC_DIV1, 0);
  TIM1_ICInit(TIM1_CHANNEL_2,  TIM1_ICPOLARITY_FALLING,TIM1_ICSELECTION_INDIRECTTI, TIM1_ICPSC_DIV1, 0);
  TIM1_SelectInputTrigger(TIM1_TS_TI1FP1);
  TIM1_SelectSlaveMode(TIM1_SLAVEMODE_RESET);
  
  TIM1_ClearFlag(TIM1_FLAG_CC2);
  TIM1_ITConfig(TIM1_IT_CC2, ENABLE);// ��������� ����������
  
  TIM1_Cmd(ENABLE);// ��������� ������
  
  //TIM2_CH1 - PWM
  TIM2_DeInit();
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER2, ENABLE);
  TIM2_TimeBaseInit(TIM2_PRESCALER_64,200);//16M/64/200 = 1250
  TIM2_OC1Init(TIM2_OCMODE_PWM1, TIM2_OUTPUTSTATE_ENABLE, 0, TIM2_OCPOLARITY_HIGH); 
  TIM2_OC2PreloadConfig(ENABLE);
  TIM2_Cmd(ENABLE);
}




void IWDG_Config(void)
{
  IWDG_Enable();
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  
  IWDG_SetPrescaler(IWDG_Prescaler_256);
  IWDG_SetReload(255);
  /* Reload IWDG counter */
  IWDG_ReloadCounter();
  /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
}



void init_uart(void)
{
  UART2_DeInit();
  UART2_Init((uint32_t)19200, UART2_WORDLENGTH_8D, UART2_STOPBITS_1, UART2_PARITY_NO,
                UART2_SYNCMODE_CLOCK_DISABLE, UART2_MODE_TX_ENABLE);
  UART2_Cmd(ENABLE);
}

void init_adc(void)
{
  ADC1_DeInit();
  ADC1_Init(ADC1_CONVERSIONMODE_SINGLE, ADC1_CHANNEL_1,  ADC1_PRESSEL_FCPU_D10, \
            ADC1_EXTTRIG_TIM, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL1,\
            DISABLE);
  
}