#include "stm8l15x_conf.h"
// !!! Edit stm8l15x_conf.h to enable peripheral header
// !!! Test STM8L15X_MD in stm8l15x.h to the target STM8L device used
// Current selected:
// STM8L15x devices are STM8L151C4, STM8L151C6, STM8L152C4,
// STM8L152C6, STM8L151K4, STM8L151K6, STM8L152K4, STM8L152K6, STM8L151G4,
// STM8L151G6, STM8L152G4 and STM8L152G6
void main( void )
{
  //Paste your code here :)
}
