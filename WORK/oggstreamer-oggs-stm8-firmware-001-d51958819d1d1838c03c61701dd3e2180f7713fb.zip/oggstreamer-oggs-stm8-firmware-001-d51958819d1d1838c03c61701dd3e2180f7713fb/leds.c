/*
Copyright (C) 2011 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "includes.h"

unsigned char leds_status, leds_left, leds_right;
unsigned char updatevuflag;
unsigned char blinkinterval;
unsigned char freetimer;


void InitLEDS()
{
  PORT_LEDS->DDR = 0xFF;
  PORT_LEDS->CR1 = 0xFF;
  PORT_MUX->DDR |= PIN_MUX_STATUS | PIN_MUX_LEFT | PIN_MUX_RIGHT;
  PORT_MUX->CR1 |= PIN_MUX_STATUS | PIN_MUX_LEFT | PIN_MUX_RIGHT;
  PORT_ONAIR->DDR |= PIN_ONAIR;
  PORT_ONAIR->CR1 |= PIN_ONAIR;

  GPIOA->ODR |= BIT(3);
  
#ifdef LEDS_PROFILE_ON
  GPIOG->DDR = GPIO_PIN_0;
  GPIOG->CR1 = GPIO_PIN_0;
#endif
  
  SetOnAirLED(0,0);
  
  TIM4_DeInit();
  TIM4_TimeBaseInit(TIM4_PRESCALER_128,255);
  TIM4_ITConfig(TIM4_IT_UPDATE,ENABLE);
  TIM4_Cmd(ENABLE);
}

void SetOnAirLED(unsigned char onoff, unsigned char blinkhz)
{
  if(blinkhz == 0)
  {
    if(onoff)
    {
      PORT_ONAIR->ODR |= PIN_ONAIR;
    } else {
      PORT_ONAIR->ODR &= ~PIN_ONAIR;
    }
    
    blinkinterval = 0;
  } else {
    blinkinterval = (unsigned char)(TIM4_HZ / 2 / (unsigned short)blinkhz);
  }
}

#if defined(__ICCSTM8__)
#pragma vector = TIM4_OVR_UIF_vector 
__interrupt void TIM_Update_vector(void)
#elif defined(SDCC)
void TIM_Update_vector(void) __interrupt(TIM4_OVR_UIF_vector)
#endif

{
  static unsigned char turn=0;
  static unsigned char updatecounter=0;
  static unsigned char onairblink_cnt=0; 
#ifdef STATISTICS_DISPLAY_BUFFER_STATUS
  static int buffer_rolling_median=0;
#endif

#ifdef LEDS_PROFILE_ON
  GPIOG->ODR = GPIO_PIN_0;
#endif
  
  freetimer++;
  
  updatecounter++;
  
  if(updatecounter >= UPDATE_VU_INTERVAL)
  {
    updatevuflag = 1;
    updatecounter = 0;
  }
  
  if(blinkinterval)
  {
    onairblink_cnt++;
    if(onairblink_cnt > blinkinterval)
    {
      PORT_ONAIR->ODR = PORT_ONAIR->ODR ^ PIN_ONAIR;
      onairblink_cnt = 0;
    }
  }
  
  PORT_MUX->ODR &= ~( PIN_MUX_STATUS | PIN_MUX_LEFT | PIN_MUX_RIGHT );
  
  switch(turn)
  {
  case 0:
    PORT_MUX->ODR |= PIN_MUX_STATUS;
    PORT_LEDS->ODR=leds_status;
    break;
  case 1:
    PORT_MUX->ODR |= PIN_MUX_LEFT;
    PORT_LEDS->ODR=leds_left;
    break;
  case 2:
    PORT_MUX->ODR |= PIN_MUX_RIGHT;
#ifdef STATISTICS_DISPLAY_BUFFER_STATUS
    if(buffer_status) buffer_rolling_median = (buffer_rolling_median * 4) / 5 + buffer_status / 5;
    PORT_LEDS->ODR = buffer_rolling_median / 16;
#else
    PORT_LEDS->ODR=leds_right;
#endif
    break;
  }
  
  turn++;
  if(turn >= 3) turn=0;
   
  TIM4_ClearITPendingBit(TIM4_IT_UPDATE);  
 
#ifdef STATISTICS_DATA_RATE
  if(data_rate_counter >= 112)
  {
    data_rate = data_rate_sumup << 5;
    data_rate_sumup = 0;
    data_rate_counter = 0;
  }
  data_rate_counter++;
#endif
  
#ifdef LEDS_PROFILE_ON
  GPIOG->ODR = 0;
#endif
 
}
