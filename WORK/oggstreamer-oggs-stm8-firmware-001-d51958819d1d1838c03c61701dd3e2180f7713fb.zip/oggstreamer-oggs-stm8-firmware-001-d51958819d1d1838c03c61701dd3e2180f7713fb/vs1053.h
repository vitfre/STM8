#ifndef __VS1053_H__
#define __VS1053_H__

#define VS1053_STREAMOGG_PARAM_MAXBLOCKSIZE 	512

#define VS1053_HDAT1_READ_DELAY 8 // 8 tick @ 450Hz aprx. 18ms

#define VS1053_GPIO_SPI GPIOC
#define VS1053_GPIO_CTRL GPIOE
#define VS1053_PIN_CS GPIO_PIN_1
#define VS1053_PIN_BSYNC GPIO_PIN_2
#define VS1053_PIN_DREQ GPIO_PIN_1
#define VS1053_PIN_RESET GPIO_PIN_0

#define VS1053_SPI_CS_OFF ( ( VS1053_GPIO_SPI->ODR ) |= VS1053_PIN_CS )
#define VS1053_SPI_CS_ON ( ( VS1053_GPIO_SPI->ODR) &= (~VS1053_PIN_CS) )
#define VS1053_CHECK_DREQ ((VS1053_GPIO_CTRL->IDR) & VS1053_PIN_DREQ)
#define VS1053_CHECK_BSYNC ((VS1053_GPIO_CTRL->IDR) & VS1053_PIN_BSYNC)
#define VS1053_CHECK_XPORTRTS ((GPIOD->IDR) & GPIO_PIN_4)


#define VS1053_CMD_WRITE	0x02
#define VS1053_CMD_READ		0x03
#define VS1053_REG_MODE		0x00
#define VS1053_REG_STATUS	0x01
#define VS1053_REG_BASS		0x02
#define VS1053_REG_CLOCKF	0x03
#define VS1053_REG_DECODE_TIME	0x04
#define VS1053_REG_AUDATA	0x05
#define VS1053_REG_WRAM		0x06
#define VS1053_REG_WRAMADDR	0x07
#define VS1053_REG_HDAT0		0x08
#define VS1053_REG_HDAT1		0x09
#define VS1053_REG_AIADDR	0x0A
#define VS1053_REG_VOL			0x0B
#define VS1053_REG_AICTRL0	0x0C
#define VS1053_REG_AICTRL1	0x0D
#define VS1053_REG_AICTRL2	0x0E
#define VS1053_REG_AICTRL3	0x0F
#define VS1053_ADDR_DDR			0xC017
#define VS1053_ADDR_IDATA		0xC018
#define VS1053_ADDR_ODATA		0xC019
#define VS1053_ADDR_INT_ENABLE 0xC01A
#define VS1053_CLOCK_5_5	        0xC800
#define VS1053_CLOCK_5		        0xe000
#define VS1053_CLOCK_4_5		0xc000
#define VS1053_CLOCK_1			0x0000

//Bits in Mode Register
#define VS1053_SM_DIFF		BIT(0)
#define VS1053_SM_LAYER12 	BIT(1)
#define VS1053_SM_RESET 	BIT(2)
#define VS1053_SM_CANCEL 	BIT(3)
#define VS1053_SM_EARSPEAKER_LO BIT(4)
#define VS1053_SM_TESTS 	BIT(5)
#define VS1053_SM_STREAM 	BIT(6)
#define VS1053_SM_EARSPEAKER_HI BIT(7)
#define VS1053_SM_DACT 		BIT(8)
#define VS1053_SM_SDIORD 	BIT(9)
#define VS1053_SM_SDISHARE 	BIT(10)
#define VS1053_SM_SDINEW 	BIT(11)
#define VS1053_SM_ADPCM 	BIT(12)
#define VS1063_SM_ENCODE 	BIT(12)
#define VS1053_SM_LINE1		BIT(14)
#define VS1053_SM_CLK_RANGE     BIT(15)

#define VS1063_SS_REFERENCE_SEL BIT(0)


//VS1063 Specific
#define VS1063_CHANNELMAX_LEFT 0x1e3c
#define VS1063_CHANNELMAX_RIGHT 0x1e3d
#define VS1063_ENDFILLBYTE 0x1e06
#define VS1063_PLAYMODE 0x1e09


#define VS1063_AICTRL3_ENCODER_OGG (5<<4)
#define VS1063_AICTRL3_ENCODER_MP3 (6<<4)
#define VS1063_AICTRL3_ENCODER_MASK 0x00f0
#define VS1063_AICTRL3_ADC_JOINTSTEREO 0
#define VS1063_AICTRL3_ADC_DOWNMIXMONO 4
#define VS1063_AICTRL3_ADC_MASK 0x0008

struct VS1063_OPTIONS {
  unsigned short samplerate;
  unsigned char quality;
  unsigned short kbitrate;
  unsigned char bitratemode;
  unsigned short aictrl3;
};


extern struct VS1063_OPTIONS vs1063_options;
extern const unsigned short vs1063_samplerate[9];

extern void VS1053WriteRegister(unsigned char reg, unsigned short val);
extern unsigned short VS1053ReadRegister(unsigned char reg);
extern void VS1053WriteWram(unsigned short addr, unsigned short val);
extern unsigned short VS1053ReadWram(unsigned short addr);
extern void VS1053SetGPIO(unsigned char gpio);
extern unsigned char VS1053GetGPIO(void);
extern void InitVS1053(void);
extern void VS1053Reset(void);
extern void VS1053LoadPlugin(void);
extern void VS1053WriteIWram(unsigned short addr, unsigned long val);
extern unsigned long VS1053ReadIWram(unsigned short addr);
extern void VS1053StreamOgg(void);
extern void VS1053StreamOggClose(void);
extern unsigned char VS1053LevelMeter(unsigned short l);
extern void VS1063DispVUMeter(void);
extern void VS1063StartOgg(void);
extern void VS1063StreamOggClose(void);
extern void InitVS1053Vars(void);
extern int LoadVS1063Patch(void);
extern void VS1053WaitDreqTimeout();


#define VS1053StopStreaming() VS1053WriteRegister(VS1053_REG_AICTRL3,BIT(0))
#define VS1063StopStreaming() VS1053WriteRegister(VS1053_REG_MODE,VS1053_SM_CANCEL)
#define VS1053HasStopped() VS1053ReadRegister(VS1053_REG_AICTRL3) & BIT(1)
#define VS1063HasStopped() (!(VS1053ReadRegister(VS1053_REG_MODE) & VS1063_SM_ENCODE))

#endif //__VS1053_H__
