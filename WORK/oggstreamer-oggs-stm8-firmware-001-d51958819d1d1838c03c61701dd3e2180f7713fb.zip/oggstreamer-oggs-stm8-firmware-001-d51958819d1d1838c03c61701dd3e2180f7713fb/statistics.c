/*
Copyright (C) 2011 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "includes.h"

unsigned short buffer_status;
unsigned long data_rate_sumup;
unsigned long data_rate;
unsigned short data_rate_counter;
unsigned char rs232_rx_errors;


void InitStatistics(void)
{
  
  buffer_status = 0;
  data_rate_sumup = 0;
  data_rate = 0;
  data_rate_counter = 0;
  rs232_rx_errors = 0;
}