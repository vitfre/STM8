/*
Copyright (C) 2012 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "includes.h"

unsigned char rx_ring[256];
unsigned char rx_head;
unsigned char rx_tail;


void InitRXBuffer()
{
  rx_head = 0;
  rx_tail = 0;
  ITC_SetSoftwarePriority(ITC_IRQ_UART2_RX, ITC_PRIORITYLEVEL_3);
  UART2_ITConfig(UART2_IT_RXNE_OR, ENABLE);
}

#if defined(__ICCSTM8__)
#pragma vector = UART2_RX_vector
__interrupt void UART_RX_vector(void)
#elif defined(SDCC)
void UART_RX_vector(void) __interrupt(UART2_RX_vector)
#endif
{
  
  rx_ring[rx_head] = UART2->DR;
  
  if(UART2_HasError())
  {
#if defined(STATISTICS_RS232_RX_ERROR)
    rs232_rx_errors++;
#endif
  } else { 
    rx_head++;
  }
  
}

unsigned char RXBuffer_HasBytes()
{
  return rx_head - rx_tail;
}

unsigned char RXBuffer_ReadBytes()
{
  unsigned char temp;
  
  temp = rx_ring[rx_tail];
  rx_tail++;
 
  return temp;
}

void UART2_WaitTX()
{
//	while(!VS1053_CHECK_XPORTRTS);
	while(!(UART2->SR & UART2_SR_TXE));
}
