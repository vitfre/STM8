/**
  ******************************************************************************
  * @file uid.c
  * @brief Readout STM8S Unique ID Register
  * @author Georg Ottinger
  * @version V0.0.1
  * @date 10-APR-2012
  ******************************************************************************
 
    Copyright (C) 2013 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "includes.h"

void send_uid()
{
  uint8_t i;
  uint8_t *p;
  
  p=(uint8_t*)UID_ADDR;
  for(i=0; i < UID_SIZE; i++)
  {
    UART2_WaitTX();
    UART2_SendData8(*p++);
  }
}

void send_versioninfo()
{
  uint8_t i;
  uint8_t *p;
  
  p=(uint8_t*)VERSION_ADDR;
  for(i=0; i < VERSION_SIZE; i++)
  {
    UART2_WaitTX();
    UART2_SendData8(*p++);
  }
}

