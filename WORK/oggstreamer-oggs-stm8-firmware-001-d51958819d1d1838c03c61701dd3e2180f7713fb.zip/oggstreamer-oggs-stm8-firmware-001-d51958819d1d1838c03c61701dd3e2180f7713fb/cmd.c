/**
  ******************************************************************************
  * @file cmd.c
  * @brief CMD-Handler for STM8.
  * Application example.
  * @author Georg Ottinger
  * @version V0.0.2
  * @date 10-APR-2012
  ******************************************************************************
 
    Copyright (C) 2011 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


/* Includes ------------------------------------------------------------------*/
#include "includes.h"


unsigned char state = STATE_IDLE;


void cmd_stm(void)
{
    switch(state)
    {
      case STATE_IDLE:
        leds_left = 0;
        leds_right = 0;
	break;
				
      case STATE_STARTSTREAMING:
        write_state_eeprom(1);
        InitVS1053();
	VS1063StartOgg();
	state = STATE_STREAMING;
	break;
				
      case STATE_STREAMING:
	VS1053StreamOgg();
        VS1063DispVUMeter();        
	break;
				
      case STATE_STOPSTREAMING_STAGE1:
        write_state_eeprom(0);
        VS1063StopStreaming();	
	state = STATE_STOPSTREAMING_STAGE2;
	break;
      
      case STATE_STOPSTREAMING_STAGE2:
	VS1053StreamOgg();

	if(VS1063HasStopped())
        {
	  VS1063StreamOggClose();
	  state = STATE_IDLE;
	}
	break;
        
      case STATE_STARTVUONLY:
        InitVS1053();
	VS1063StartOgg();
	state = STATE_VUONLY;
	break;
        
      case STATE_VUONLY:
        VS1063DispVUMeter();        
	break;
        
      case STATE_STOPVUONLY_STAGE1:
        VS1063StopStreaming();	
	state = STATE_STOPVUONLY_STAGE2;  
        break;
        
      case STATE_STOPVUONLY_STAGE2:
	if(VS1063HasStopped())
        {
	  state = STATE_IDLE;
	}
	break;    

    default:
	break;
    }
}


void process_cmd(void)
{
  unsigned char cmd;
  unsigned char arg;
  
  cmd = RXBuffer_ReadBytes();
  arg = cmd & 0xf;
  cmd &= 0xf0;
  
  switch(cmd)
  {
 
 case CMD_CTRL:   
    switch(arg)
    {
    case ARG_CTRL_STARTSTREAM:
      state=STATE_STARTSTREAMING;
      break;
    case ARG_CTRL_VUONLY:
      state=STATE_STARTVUONLY;
      break;
    case ARG_CTRL_STOPSTREAM:
      state = STATE_STOPSTREAMING_STAGE1;
      break;
    case ARG_CTRL_STOPVUONLY:
      state=STATE_STOPVUONLY_STAGE1;
    default:
      break;
    }
    break;

  case CMD_ONAIR:
    SetOnAirLED(arg,0);
    break;

  case CMD_ONAIRBLINK:
    SetOnAirLED(1,arg);
    break;

  case CMD_SET_QUALITY:
    if(arg <= 10)
    {
      vs1063_options.quality = arg; 
      vs1063_options.bitratemode = 0;
    }
    break;

  case CMD_SET_BITRATE:
    vs1063_options.kbitrate = 32 + (unsigned short)arg * 16;
    vs1063_options.bitratemode = 1;
    break;

  case CMD_STATUSLED_LEFT:
    leds_status &= 0x0f;
    leds_status |= arg << 4;
    break;

  case CMD_STATUSLED_RIGHT:
    leds_status &= 0xf0;
    leds_status |= (arg&0x4) >> 2 | (arg&0x2) | (arg&0x1) << 2;
    break;

  case CMD_SAMPLERATE:
    if(arg < (sizeof(vs1063_samplerate)/2))
      vs1063_options.samplerate=vs1063_samplerate[arg];
    break;

  case CMD_GETSTATUS:
    switch(arg)
    {
    case ARG_GETSTATUS_UID:
      send_uid();
      break;
    case ARG_GETSTATUS_EEPROMSTATE:
      UART2_WaitTX();
      UART2_SendData8(eepromstate.last_state);
      break;
    case ARG_GETSTATUS_VERSIONINFO:
      send_versioninfo();
      break;
    default:
      break;
    }
    break;

  case CMD_SET_OPTIONS:
    if(arg & ARG_SET_OPTIONS_DOWNMIXMONO)
      vs1063_options.aictrl3 = (vs1063_options.aictrl3 & ~VS1063_AICTRL3_ADC_MASK) | VS1063_AICTRL3_ADC_DOWNMIXMONO; 
    else
      vs1063_options.aictrl3 = (vs1063_options.aictrl3 & ~VS1063_AICTRL3_ADC_MASK) | VS1063_AICTRL3_ADC_JOINTSTEREO; 
    if(arg & ARG_SET_OPTIONS_ENCODER_MP3)
      vs1063_options.aictrl3 = (vs1063_options.aictrl3 & ~VS1063_AICTRL3_ENCODER_MASK) | VS1063_AICTRL3_ENCODER_MP3;
    else
      vs1063_options.aictrl3 = (vs1063_options.aictrl3 & ~VS1063_AICTRL3_ENCODER_MASK) | VS1063_AICTRL3_ENCODER_OGG; 
    break;

  default:
    break;
  }

}
