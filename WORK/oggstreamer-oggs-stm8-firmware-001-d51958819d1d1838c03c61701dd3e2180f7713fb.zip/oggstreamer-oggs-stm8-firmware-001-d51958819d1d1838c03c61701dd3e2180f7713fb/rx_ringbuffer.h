/*
Copyright (C) 2012 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef __RX_RINGBUFFER_H__
#define __RX_RINGBUFFER_H__

#define UART2_IsRX() (UART2->SR & UART2_SR_RXNE)
#define UART2_HasError() (UART2->SR & (UART2_SR_OR | UART2_SR_FE | UART2_SR_PE | UART2_SR_NF))

#if defined(__ICCSTM8__)
#define UART2_RX_vector 0x17
#elif defined(SDCC)
#define UART2_RX_vector 21
#endif



extern void InitRXBuffer();
extern unsigned char RXBuffer_HasBytes();
extern unsigned char RXBuffer_ReadBytes();
extern void UART2_WaitTX(void);

#if defined(SDCC)
extern void UART_RX_vector(void) __interrupt(UART2_RX_vector);
#endif

#endif

