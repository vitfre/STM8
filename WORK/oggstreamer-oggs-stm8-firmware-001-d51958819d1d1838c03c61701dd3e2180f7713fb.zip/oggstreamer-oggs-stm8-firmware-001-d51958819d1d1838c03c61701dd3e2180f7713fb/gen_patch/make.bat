set PATH=%PATH%;C:\mingw\bin
del gen_patch.exe
gcc gen_patch.c -o gen_patch.exe
gen_patch
bin2hex vsdsp_patch.bin vsdsp_patch.hex -o 0xa000