#include <stdio.h>
#include "vs1063a-patches.plg"

#define MSB(x)	( ( (x) >> 8 ) & 0xFF )
#define LSB(x)	( (x) & 0xFF )

const char patch_magicstring[4] = {'V','l','S','i'};

int main()
{
	int i;
	unsigned short plugin_size;
	
	FILE *fp;
	
	fp=fopen("vsdsp_patch.bin","wb");

	//magic string
	fputc(patch_magicstring[0],fp);
	fputc(patch_magicstring[1],fp);
	fputc(patch_magicstring[2],fp);
	fputc(patch_magicstring[3],fp);

	//patch size
	plugin_size = PLUGIN_SIZE;
	fputc(MSB(plugin_size),fp);
	fputc(LSB(plugin_size),fp);
	
	for(i = 0; i < plugin_size; i++)
	{
		fputc(MSB(plugin[i]),fp);
		fputc(LSB(plugin[i]),fp);
	}
	
	fclose(fp);
}
