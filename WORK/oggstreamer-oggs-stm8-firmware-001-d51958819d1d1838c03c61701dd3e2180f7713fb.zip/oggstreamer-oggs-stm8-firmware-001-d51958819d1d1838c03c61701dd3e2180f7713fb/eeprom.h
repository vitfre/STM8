/**
  ******************************************************************************
  * @file eeprom.h
  * @brief EEPROM State preserve mechanism
  * @author Georg Ottinger
  * @version V0.0.1
  * @date 10-APR-2012
  ******************************************************************************
 
    Copyright (C) 2013 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __EEPROM_H__
#define __EEPROM_H__

//#define EEPROM_SUPER_COMPLICATED

struct {
  uint8_t pcid;
  uint8_t fresh_powercycle;
  uint8_t last_state;
  uint8_t pristine;
  uint16_t last_addr;
} typedef EEPROMSTATE;


#define EEPROM_STARTADDR 0x004000 
#define EEPROM_GRANULARITY 4 
//#define EEPROM_BYTES 254
#define EEPROM_BYTES 8
#define EEPROM_STATES 2




extern EEPROMSTATE eepromstate;

extern void init_eeprom(void);
extern void get_last_pcid_eeprom(void);
extern uint8_t get_last_state_eeprom(void);
extern void write_state_eeprom(uint8_t state);
#endif