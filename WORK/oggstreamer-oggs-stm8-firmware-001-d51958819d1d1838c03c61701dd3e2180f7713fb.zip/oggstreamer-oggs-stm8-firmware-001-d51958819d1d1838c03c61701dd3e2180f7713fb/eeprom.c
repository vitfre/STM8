/**
  ******************************************************************************
  * @file eeprom.c
  * @brief EEPROM State preserve mechanism
  * @author Georg Ottinger
  * @version V0.0.1
  * @date 10-APR-2012
  ******************************************************************************
 
    Copyright (C) 2013 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "includes.h"

EEPROMSTATE eepromstate;

#ifdef EEPROM_SUPER_COMPLICATED
void init_eeprom()
{
  /* Define FLASH programming time */
  FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);
  /* Unlock Data memory */
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
    
  eepromstate.pristine = 0; 
  get_last_pcid_eeprom();
  get_last_state_eeprom();
  eepromstate.pcid++;

}


void write_state_eeprom(uint8_t state)
{
  uint8_t i;
  
  
  if(state == 0)
  {
    eepromstate.pcid++; //implies MOD 256 
  } else if( state < eepromstate.last_state ) {
    eepromstate.pcid++; //implies MOD 256
    eepromstate.last_state = 0;
    eepromstate.last_addr++; 
    eepromstate.last_addr %= EEPROM_BYTES;
    FLASH_ProgramByte(EEPROM_STARTADDR+(eepromstate.last_addr  * EEPROM_GRANULARITY),eepromstate.pcid); 
  }
  
  if(state == 0)
  {
    eepromstate.last_addr++; 
    eepromstate.last_addr %= EEPROM_BYTES;
    FLASH_ProgramByte(EEPROM_STARTADDR+(eepromstate.last_addr  * EEPROM_GRANULARITY),eepromstate.pcid); 
  } else {
    for( i = 0; i < (state - eepromstate.last_state); i++)
    {
      
      eepromstate.last_addr++; 
      eepromstate.last_addr %= EEPROM_BYTES;
      FLASH_ProgramByte(EEPROM_STARTADDR+(eepromstate.last_addr  * EEPROM_GRANULARITY),eepromstate.pcid); 
    }
  }
  
  eepromstate.last_state = state;
}

//Counts backwards to find the number of 
uint8_t get_last_state_eeprom()
{
  uint16_t addr;
  uint8_t cur_byte,cnt;
 
  if(eepromstate.pristine)
    return 0;
  
  cnt = 0;
  addr = eepromstate.last_addr-1;
  if(addr == 256) //wrap around
  {
    addr = EEPROM_BYTES-1;
  }
  
  do {
    cur_byte = FLASH_ReadByte(EEPROM_STARTADDR+(addr * EEPROM_GRANULARITY));
    addr--;
    if(addr == 256) //wrap around
    {
      addr = EEPROM_BYTES-1;
    }
    cnt++;
  } while( cur_byte == eepromstate.pcid && cnt <= EEPROM_BYTES);
  
  cnt--;
  eepromstate.last_state = cnt % EEPROM_STATES;
  
  return eepromstate.last_state;
}

void get_last_pcid_eeprom()
{
  uint8_t last_byte, cur_byte, found;
  uint16_t addr;

  found = 0;
    
  last_byte = FLASH_ReadByte( EEPROM_STARTADDR );
  for( addr = 1; addr < EEPROM_BYTES; addr ++)
  {
    cur_byte = FLASH_ReadByte( EEPROM_STARTADDR + (addr*EEPROM_GRANULARITY));
   
    if( (uint8_t)(cur_byte - last_byte) >= 2 ) // implies MOD 256
    {
      eepromstate.last_addr = addr - 1;
      eepromstate.pcid = last_byte;
      found = 1;
      break;
    }
    
    last_byte = cur_byte;
  }
  
  if(!found)
  {
    cur_byte = FLASH_ReadByte( EEPROM_STARTADDR );
    if( (uint8_t)(cur_byte - last_byte ) >= 2 ) // implies MOD 256
    {
      eepromstate.last_addr = EEPROM_BYTES;
      eepromstate.pcid = last_byte;
    } else { // pristine EEPROM condition
      eepromstate.pristine = 1;
      eepromstate.last_addr = 0;
      eepromstate.pcid = 0;
      eepromstate.last_state = 0;
    }
  }
}
#else
void init_eeprom()
{
  /* Define FLASH programming time */
  FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);
  /* Unlock Data memory */
  FLASH_Unlock(FLASH_MEMTYPE_DATA);
  
  eepromstate.last_state = FLASH_ReadByte(EEPROM_STARTADDR);
  
  if (eepromstate.last_state >= EEPROM_STATES)
  {
    eepromstate.last_state = 0;
  }
}

void write_state_eeprom(uint8_t state)
{

  eepromstate.last_state = state;

  if(eepromstate.last_state >= EEPROM_STATES)
  {
    eepromstate.last_state = 0;
  } 

  FLASH_ProgramByte(EEPROM_STARTADDR,eepromstate.last_state); 

}

#endif
