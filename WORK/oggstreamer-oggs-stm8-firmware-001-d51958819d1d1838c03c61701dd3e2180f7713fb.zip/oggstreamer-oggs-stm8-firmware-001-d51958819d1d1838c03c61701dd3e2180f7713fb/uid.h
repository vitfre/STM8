/**
  ******************************************************************************
  * @file uid.h
  * @brief Readout STM8S Unique ID Register
  * @author Georg Ottinger
  * @version V0.0.1
  * @date 10-APR-2012
  ******************************************************************************
 
    Copyright (C) 2013 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef __UID_H__
#define __UID_H__

#define UID_ADDR 0x48CD
#define UID_SIZE 12

/* Defined from the Makefile
#define VERSION_ADDR 0xFFC0
#define VERSION_SIZE 64
*/

extern void send_uid(void);
extern void send_versioninfo(void);
#endif
