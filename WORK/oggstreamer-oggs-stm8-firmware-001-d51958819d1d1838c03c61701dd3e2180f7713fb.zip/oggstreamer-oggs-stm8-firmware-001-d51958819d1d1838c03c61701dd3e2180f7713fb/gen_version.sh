#!/bin/sh

VERSIONNUMBER_FILE=versionnumber.txt
VERSION_INFO=version.txt

vver=$(cat $VERSIONNUMBER_FILE)
vdate=$(date +"%Y%m%d %T")
vsdcc=$(sdcc --version | cut -d \# -f 2 | cut -d ' ' -f 1)

echo $vver $vdate SDCC\#$vsdcc > $VERSION_INFO
