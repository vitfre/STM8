/*
Copyright (C) 2011 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "includes.h"

void InitCPUSpeed()
{
	CLK->SWCR |= CLK_SWCR_SWEN;				//finalize clock source change
	CLK->SWR = (u8)CLK_SOURCE_HSE; 		//choose external Oszilator	

	while(!(CLK->SWCR & CLK_SWCR_SWIF)) //wait for Clock to settle
//	CLK->SWCR |= CLK_SWCR_SWEN;				//finalize clock source change
	CLK->CKDIVR = 0;		// prescaler for Internal Clock and CPU Clock is 1
	//the internal Bus and the CPU should now run at the speed of the external Oszillator
}

void InitSPI(SPI_BaudRatePrescaler_TypeDef prescaler)
{
  
        while(SPI->SR & SPI_FLAG_BSY);
	SPI->CR1 = SPI_FIRSTBIT_MSB|(u8)prescaler|SPI_MODE_MASTER|SPI_CLOCKPOLARITY_LOW|SPI_CLOCKPHASE_1EDGE;
	SPI->CR2 = 0x03; //SSM and SSI
	SPI->CR1 |= 0x40; //Enable SPI;
	SPI->DR = 0;
}
