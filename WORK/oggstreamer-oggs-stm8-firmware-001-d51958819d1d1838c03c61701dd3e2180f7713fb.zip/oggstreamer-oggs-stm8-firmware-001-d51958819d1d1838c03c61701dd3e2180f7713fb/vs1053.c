/**
  ******************************************************************************
  * @file vs1053.c
  * @brief Routines for VS10x3 Handling
  * Application example.
  * @author Georg Ottinger
  * @version V0.0.1
  * @date 31-DEC-2011
  ******************************************************************************
 
    Copyright (C) 2011 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


#include "includes.h"


const char patch_magicstring[4] = {'V','l','S','i'};

#ifdef PATCH_DREQ_DEBUG
unsigned short patchpos=0;
#endif

unsigned char dreq_timeout=0;
        
struct VS1063_OPTIONS vs1063_options;

const unsigned short vs1063_samplerate[9] = {
  8000,
  11025,
  12000,
  16000,
  22050,
  24000,
  32000,
  44100, //not recommended (cause 0,23% deviation 44201Hz)
  48000
};
  


//const char decibel_vol[8] = {
//   	2,	//-30db
//  	6,	//-20db
//  	16,	//-12db
//  	32, //-6db
//  	45, //-3db
//  	64, //0db
//  	90, //3 db
//  	113, //5 db
//};

const unsigned short decibel_vol[8] = {
  164, //-40dB
  518, //-30dB
  1638, //-20dB
  4115, //-12dB
  8211, //-6dB
  16384, //0dB
  23143, //3dB
  29135, //5dB
};

void VS1053WaitDreqTimeout()
{
    unsigned char delay;
    
    delay = freetimer;
    while(!VS1053_CHECK_DREQ && ((unsigned char)(freetimer-delay) <= 5));
    
    if ( !((unsigned char)(freetimer-delay) <= 5))
      dreq_timeout++;
}


int LoadVS1063Patch(void) {
  volatile unsigned short i = 0;
  
  volatile char *patch_magic; //@ 0xa000
  volatile unsigned short *patch_len; //@ 0xa004
  volatile unsigned short *patch_data; //@ 0xa006

  //Patch is placed at offset 0xa0000
  patch_magic = (char *)0xa000;
  patch_len = (unsigned short*)0xa004;
  patch_data = (unsigned short*)0xa006;
  
  
  if(strncmp(patch_magicstring, patch_magic, 4))
  {
    //Magic String not found
    return 0;
  }

  while (i<*patch_len) {
    unsigned short addr, n, val;
    addr = patch_data[i++];
    n = patch_data[i++];

    if (n & 0x8000U) { // RLE run, replicate n samples 
      n &= 0x7FFF;
      val = patch_data[i++];

      while (n--) {
#ifdef PATCH_DREQ_DEBUG
        patchpos=i;
#endif
        VS1053WriteRegister(addr, val);
        if(dreq_timeout) return -1;
      }
    } else {           // Copy run, copy n samples 
      while (n--) {
        val = patch_data[i++];

#ifdef PATCH_DREQ_DEBUG
        patchpos=i;
#endif
        VS1053WriteRegister(addr, val);
        if(dreq_timeout) return -1;
      }
    }
  }

  VS1053WaitDreqTimeout();
//  while(!VS1053_CHECK_DREQ);   
  return 1;
}


void InitVS1053(void)
{
  
        VS1053_GPIO_CTRL->DDR |= VS1053_PIN_RESET;
        VS1053_GPIO_CTRL->CR1 |= VS1053_PIN_RESET;
        VS1053_GPIO_SPI->DDR |= VS1053_PIN_CS;
        VS1053_GPIO_SPI->CR1 |= VS1053_PIN_CS;
        
        do {
          
          dreq_timeout = 0;
          
          InitSPI(SPI_BAUDRATEPRESCALER_256);		//Slow SPI for Initialization
  
          VS1053Reset();
          
          VS1053WriteRegister(VS1053_REG_MODE, VS1053_SM_SDINEW | VS1053_SM_SDISHARE);
          
          
          //Set GPIOs as Output
          VS1053WriteWram(VS1053_ADDR_DDR,0xff);
//          VS1053WriteRegister(VS1053_REG_CLOCKF,VS1053_CLOCK_5); // set to  61,44 Mhz Operation	
          VS1053WriteRegister(VS1053_REG_CLOCKF,VS1053_CLOCK_5_5); // set to  67,58 Mhz Operation	
          
	  InitSPI(SPI_BAUDRATEPRESCALER_4);		//fast SPI approx 3,68 M/bits (Datasheet allows max. 3,5M/Bits)
                   
	  VS1053WriteRegister( VS1053_REG_STATUS, VS1053ReadRegister(VS1053_REG_STATUS) | VS1063_SS_REFERENCE_SEL );  //1,65 Volt Reference
  	  
            
          VS1053WaitDreqTimeout();      
          //while(!VS1053_CHECK_DREQ);   
    
          LoadVS1063Patch();

          //VS1053WriteRegister(VS1053_REG_CLOCKF,VS1053_CLOCK_5_5); // set to   67.58  Mhz Operation	
 	  
 
        } while( dreq_timeout );
        
}

void InitVS1053Vars(void)
{
        vs1063_options.samplerate = 48000;
        vs1063_options.bitratemode = 1;
        vs1063_options.kbitrate = 128;
        vs1063_options.aictrl3 = VS1063_AICTRL3_ENCODER_OGG | VS1063_AICTRL3_ADC_JOINTSTEREO;
}

void VS1053Reset(void)
{
        unsigned char delay;
          
	VS1053_GPIO_CTRL->ODR &= ~VS1053_PIN_RESET;
        //wait a little 1/450 - 2/450 s
        delay = freetimer;
        while((unsigned char)(freetimer-delay) <= 2);
 
        VS1053_GPIO_CTRL->ODR |= VS1053_PIN_RESET;
}

void VS1053WriteWram(unsigned short addr, unsigned short val)
{
	VS1053WriteRegister(VS1053_REG_WRAMADDR, addr);
	VS1053WriteRegister(VS1053_REG_WRAM, val);
}

unsigned short VS1053ReadWram(unsigned short addr)
{
	VS1053WriteRegister(VS1053_REG_WRAMADDR, addr);
	return VS1053ReadRegister(VS1053_REG_WRAM);
}

void VS1053WriteIWram(unsigned short addr, unsigned long val)
{
	unsigned short d;
	VS1053WriteRegister(VS1053_REG_WRAMADDR, addr);
	d = val >> 16;
	VS1053WriteRegister(VS1053_REG_WRAM, d);
	d = val & 0xFFFF;
	VS1053WriteRegister(VS1053_REG_WRAM, d);	
}

unsigned long VS1053ReadIWram(unsigned short addr)
{
	unsigned long d = 0;
	VS1053WriteRegister(VS1053_REG_WRAMADDR, addr);
	d = ((unsigned long)VS1053ReadRegister(VS1053_REG_WRAM))<< 16;
	d |= (unsigned long)VS1053ReadRegister(VS1053_REG_WRAM);
	return d;
}

void VS1053SetGPIO(unsigned char gpio)
{
	VS1053WriteWram(VS1053_ADDR_ODATA, gpio); 
}

unsigned char VS1053GetGPIO(void)
{
	return (unsigned char)VS1053ReadWram(VS1053_ADDR_IDATA);
}



void VS1053WriteRegister(unsigned char reg, unsigned short val) 
{
	unsigned char delay;
	      
        
        VS1053WaitDreqTimeout();
	//while(!VS1053_CHECK_DREQ);
	
        disableInterrupts();
//	SPI->CR1 |= 0x40; //Enable SPI;
		
	VS1053_SPI_CS_ON;
	
	SPI->DR = VS1053_CMD_WRITE;
	
	while(!(SPI->SR&SPI_FLAG_TXE));
	SPI->DR = reg;
	while(!(SPI->SR&SPI_FLAG_TXE));
	SPI->DR = MSB(val);
	while(!(SPI->SR&SPI_FLAG_TXE));
	SPI->DR = LSB(val);
	while(!(SPI->SR&SPI_FLAG_TXE));
	while((SPI->SR&SPI_FLAG_BSY));


	VS1053_SPI_CS_OFF;
        
        enableInterrupts();
        
        if(reg == VS1053_REG_WRAMADDR)
        {
          //wait a little 1/450 - 2/450 s
          delay = freetimer;
          while((unsigned char)(freetimer-delay) <= 2);
        } 
      
        return;
}


unsigned short VS1053ReadRegister(unsigned char reg){
	unsigned char c,d;
	unsigned short val;

	//while(!VS1053_CHECK_DREQ);
	VS1053WaitDreqTimeout();
        
        disableInterrupts();
		
	VS1053_SPI_CS_ON;
	
	c = SPI->DR; 		//DummyRead
	SPI->DR = VS1053_CMD_READ;

	while(!(SPI->SR&SPI_FLAG_TXE));
	SPI->DR = reg;
	while(!(SPI->SR&SPI_FLAG_RXNE));
	c = SPI->DR;		//Dummy Read

	while(!(SPI->SR&SPI_FLAG_TXE));
	SPI->DR = 0;
	while(!(SPI->SR&SPI_FLAG_RXNE));
	c = SPI->DR;	  //Dummy Read

	while(!(SPI->SR&SPI_FLAG_TXE));
	SPI->DR = 0;
	while(!(SPI->SR&SPI_FLAG_RXNE));
	c = SPI->DR;


	while(!(SPI->SR&SPI_FLAG_RXNE));
	d = SPI->DR;
	

	while(!(SPI->SR&SPI_FLAG_TXE));

	while((SPI->SR&SPI_FLAG_BSY));
	VS1053_SPI_CS_OFF;
	
	val = c << 8 | d ;
        
        enableInterrupts();
        
	return val;	
}




void VS1053StreamOgg(void)
{
	
	unsigned short num_words,d;
/*
	static unsigned char lastread=0;	

	while((freetimer-lastread)<VS1053_HDAT1_READ_DELAY);
	
        lastread=freetimer;	
*/
	num_words=VS1053ReadRegister(VS1053_REG_HDAT1);

#ifdef STATISTICS_BUFFER_STATUS
	buffer_status = num_words;
#endif
        
        
	if(num_words > VS1053_STREAMOGG_PARAM_MAXBLOCKSIZE)
		num_words = VS1053_STREAMOGG_PARAM_MAXBLOCKSIZE;

#ifdef STATISTICS_DATA_RATE
        disableInterrupts();
        data_rate_sumup += (num_words << 1);
        enableInterrupts();
#endif
		
	while(num_words--)
	{
		d = VS1053ReadRegister(VS1053_REG_HDAT0);
		UART2_WaitTX();
		UART2_SendData8(MSB(d));
		UART2_WaitTX();
		UART2_SendData8(LSB(d));
	}
		
}

#ifdef USE_VS1053
void VS1053StreamOggClose(void)
{
	unsigned short num_words,d;
	
	num_words=VS1053ReadRegister(VS1053_REG_HDAT1);
	
        
	num_words--; //last word is processed differently
	
	while(num_words--)
	{
		d = VS1053ReadRegister(VS1053_REG_HDAT0);
		UART2_WaitTX();
		UART2_SendData8(MSB(d));
		UART2_WaitTX();
		UART2_SendData8(LSB(d));
	}
	
	//last word
	d = VS1053ReadRegister(VS1053_REG_HDAT0);
	VS1053ReadRegister(VS1053_REG_AICTRL3);

	UART2_WaitTX();
	UART2_SendData8(MSB(d));

	
	if(!(VS1053ReadRegister(VS1053_REG_AICTRL3) & BIT(3)))
	{
		UART2_WaitTX();
		UART2_SendData8(LSB(d));

	}

}
#endif

void VS1063StreamOggClose(void)
{
  unsigned short eb;
  
  eb = VS1053ReadWram(VS1063_ENDFILLBYTE);
  
  if ((unsigned short)eb & (unsigned short)BIT(15))
  {
    UART2_WaitTX();
    UART2_SendData8(LSB(eb));
  }
}

unsigned char VS1053LevelMeter(unsigned short l)
{
  unsigned char i,n;
  
  i=7;
  do {
    if(l > decibel_vol[i])
    {
      n = 0xff;
      n <<= (7-i);
      return n;
    }
  
  } while(i--);
 	
  return 0;
}

void VS1063DispVUMeter(void)
{
  if(updatevuflag)
  {
    updatevuflag = 0;
       
    leds_left = VS1053LevelMeter(VS1053ReadWram(VS1063_CHANNELMAX_LEFT));
    leds_right = VS1053LevelMeter(VS1053ReadRegister(VS1053_REG_WRAM)); //read VS1063_CHANNELMAX_RIGHT
    VS1053WriteWram(VS1063_CHANNELMAX_LEFT, 0);
    VS1053WriteRegister(VS1053_REG_WRAM, 0); //write VS1063_CHANNELMAX_RIGHT
  }
}

void VS1063StartOgg(void)
{ 
  VS1053WriteWram( VS1063_PLAYMODE, BIT(2));
  VS1053WriteRegister( VS1053_REG_AICTRL0, vs1063_options.samplerate );
  VS1053WriteRegister( VS1053_REG_AICTRL1, 1024 );
  VS1053WriteRegister( VS1053_REG_AICTRL2, 1024 );
  VS1053WriteRegister( VS1053_REG_AICTRL3, 5<<4 ); //Ogg-Vorbis Joint Stereo Modus
  VS1053WriteRegister( VS1053_REG_AICTRL3, vs1063_options.aictrl3  ); 

  if(vs1063_options.bitratemode)
  {
    VS1053WriteRegister( VS1053_REG_WRAMADDR, 0xe000 | vs1063_options.kbitrate ); //CBR = kbitrate * 1000 bps
  } else {
    VS1053WriteRegister( VS1053_REG_WRAMADDR, vs1063_options.quality - 1 ); //map quality from 1-10 to 0-9
  }
  

  VS1053WriteRegister( VS1053_REG_MODE, VS1053ReadRegister(VS1053_REG_MODE) | VS1063_SM_ENCODE | VS1053_SM_LINE1 );
  VS1053WriteRegister( VS1053_REG_AIADDR, 0x50 );
}


