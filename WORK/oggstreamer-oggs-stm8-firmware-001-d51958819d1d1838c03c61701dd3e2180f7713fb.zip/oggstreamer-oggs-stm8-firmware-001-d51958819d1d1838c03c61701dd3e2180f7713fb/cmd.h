/*
Copyright (C) 2011 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef __CMD_H__
#define __CMD_H__

#define STATE_IDLE 0
#define STATE_STARTSTREAMING 2
#define STATE_STREAMING	1
#define STATE_STOPSTREAMING_STAGE1 3
#define STATE_STOPSTREAMING_STAGE2 4
#define STATE_STARTVUONLY 5
#define STATE_VUONLY 6
#define STATE_STOPVUONLY_STAGE1 7
#define STATE_STOPVUONLY_STAGE2 8


#define CMD_CTRL  0x10
#define CMD_ONAIR 0x20
#define CMD_ONAIRBLINK 0x30
#define CMD_SET_QUALITY 0x40
#define CMD_SET_BITRATE 0x50 //Bitrate = 32 + ARG * 16
#define CMD_STATUSLED_RIGHT 0x60
#define CMD_STATUSLED_LEFT 0x70
#define CMD_SAMPLERATE 0x80
#define CMD_GETSTATUS 0x90
#define CMD_SET_OPTIONS 0xA0


#define ARG_CTRL_STARTSTREAM 0x0
#define ARG_CTRL_VUONLY 0x1
#define ARG_CTRL_STOPSTREAM 0x2
#define ARG_CTRL_STOPVUONLY 0x3

#define ARG_GETSTATUS_UID 0x0
#define ARG_GETSTATUS_EEPROMSTATE 0x1
#define ARG_GETSTATUS_VERSIONINFO 0x2

#define ARG_SET_OPTIONS_JOINTSTEREO 0x00
#define ARG_SET_OPTIONS_DOWNMIXMONO 0x01
#define ARG_SET_OPTIONS_ENCODER_OGG 0x00
#define ARG_SET_OPTIONS_ENCODER_MP3 0x02


extern void process_cmd(void);
extern void cmd_stm(void);

#endif //__CMD_H__
