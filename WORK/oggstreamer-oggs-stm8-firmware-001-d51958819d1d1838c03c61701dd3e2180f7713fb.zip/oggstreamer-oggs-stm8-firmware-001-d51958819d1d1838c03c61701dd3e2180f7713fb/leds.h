/*
Copyright (C) 2011 Georg Ottinger

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef __LEDS_H__
#define __LEDS_H_

#define LEDS_PROFILE_ON

#if defined(__ICCSTM8__)
#define TIM4_OVR_UIF_vector 0x19
#elif defined(SDCC)
#define TIM4_OVR_UIF_vector 23
#endif

#define TIM4_HZ 450
#define UPDATE_VU_INTERVAL 15 // at 450 Hz Timer Interval aprox. 30 Hz refresh

#define PIN_MUX_STATUS GPIO_PIN_4
#define PIN_MUX_LEFT GPIO_PIN_5
#define PIN_MUX_RIGHT GPIO_PIN_6
#define PIN_ONAIR GPIO_PIN_3
#define PORT_MUX GPIOA
#define PORT_LEDS GPIOB
#define PORT_ONAIR GPIOA

extern unsigned char leds_status, leds_left, leds_right;
extern unsigned char updatevuflag;
extern unsigned char freetimer;

extern void InitLEDS();
void SetOnAirLED(unsigned char onoff, unsigned char blinkhz);

#if defined(SDCC)
extern void TIM_Update_vector(void) __interrupt(TIM4_OVR_UIF_vector);
#endif

#endif //__LEDS_H__
