/**
  ******************************************************************************
  * @file main.c
  * @brief STM8 Firmware for OggStreamer.
  * Application example.
  * @author Georg Ottinger
  * @version V0.0.1
  * @date 31-DEC-2011
  ******************************************************************************
 
    Copyright (C) 2011 Georg Ottinger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/


/* Includes ------------------------------------------------------------------*/
#include "includes.h"





/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/


/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/
/* Global variables ----------------------------------------------------------*/


/* Public functions ----------------------------------------------------------*/

/**
  ******************************************************************************
  * @brief Main function.
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  ******************************************************************************
  */

#define MAIN_PROFILING

unsigned short initcounter = 0;

void main(void)
{

#ifdef MAIN_PROFILING
  GPIOD->DDR = GPIO_PIN_0;
  GPIOD->CR1 = GPIO_PIN_0;
#endif

  
  InitStatistics();
  
  /* Configures clocks */
  InitCPUSpeed();

  /* Configures GPIOs */
  InitLEDS();
 
  UART2_Init((u32)921600, 
 		UART2_WORDLENGTH_8D,
 		UART2_STOPBITS_1, 
 		UART2_PARITY_NO, 
 		UART2_SYNCMODE_CLOCK_DISABLE,
 		UART2_MODE_TXRX_ENABLE);
  
  InitRXBuffer();
 
  enableInterrupts();

  InitVS1053Vars();
  InitVS1053();
  init_eeprom();
  
  while(1)
  { 
    
#ifdef MAIN_PROFILING
    GPIOD->ODR |= GPIO_PIN_0;
#endif 
    
    
    if(RXBuffer_HasBytes()) 
    { 
      process_cmd();
    }
    
    cmd_stm();
    
#ifdef MAIN_PROFILING                   
    GPIOD->ODR &= ~GPIO_PIN_0;
#endif
    
  }
}



/****************** (c) 2011  Georg Ottinger ******************************/
